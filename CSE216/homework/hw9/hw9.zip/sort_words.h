#ifndef __SORT_WORDS__
#define __SORT_WORDS__

//TODO: add function declarations
extern void sort_words(char **words, int wc);

#endif
