#ifndef __MAKE_WORDS__
#define __MAKE_WORDS__

//TODO: add function declarations
extern void make_words(char *str, char ***pwords, int *pwc);
extern void print_words(char **words, int wc); 

#endif

