//
// rect.c
//
#include "complex.h"
#include "rect.h"
#include <math.h>

static void to_rect(/*in*/ complex_t *self, /*out*/ rect_t **pp_res) {
    ON_FALSE_EXIT(self->ref.tag == OBJ_RECT, strmsg("not rect type"));
    *pp_res = (rect_t*)self;
    (*pp_res)->ref.addref(&(*pp_res)->ref);
}

//TODO: implement re, re( a + bi ) = a
static double re(/*in*/ complex_t *self) {
    rect_t *rec;
    to_rect(self, &rec);


}

//TODO: implement im, im( a + bi ) = b
static double im(/*in*/ complex_t *self) {
    rect_t *rec;
    to_rect(self, &rec);


}

//TODO: implement mag, mag( a + bi ) = sqrt(a*a + b*b)
static double mag(/*in*/ complex_t *self) {
    rect_t *rec;
    to_rect(self, &rec);


}

//TODO: implement ang, ang( a + bi ) = atan2(b, a)
static double ang(/*in*/ complex_t *self) {
    rect_t *rec;
    to_rect(self, &rec);


}

//write a + bi to buf
static int tostr(char *buf, /*in*/ complex_t *self) {
    rect_t *rec;
    to_rect(self, &rec);
    int ret = sprintf(buf, "%g + %g i", rec->r, rec->i);
    rec->ref.release(&rec->ref);
    return ret;
}

//TODO: implement rect_make
void rect_make(double r, double i, /*out*/ complex_t **pp_res) {
    extern void complex_add(/*in*/ complex_t *a, /*in*/ complex_t *b, /*out*/ complex_t **pp_res);
    extern void complex_sub(/*in*/ complex_t *a, /*in*/ complex_t *b, /*out*/ complex_t **pp_res);
    extern void complex_mul(/*in*/ complex_t *a, /*in*/ complex_t *b, /*out*/ complex_t **pp_res);
    extern void complex_div(/*in*/ complex_t *a, /*in*/ complex_t *b, /*out*/ complex_t **pp_res);

    rect_t *rec = refobj_alloc(OBJ_RECT, sizeof(rect_t));

    
}
