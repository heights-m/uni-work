//
// vector3.c
//
#include "common.h"
#include "vector3.h"

static void is_vec3(void *obj) {
    ON_FALSE_EXIT(((refobj_t*)obj)->tag == OBJ_VEC3, strmsg("not vec3 type"));
}

static void to_vec3(/*in*/ refobj_t *obj, /*out*/ vec3_t **pp_res) {
    ON_FALSE_EXIT(obj->tag == OBJ_VEC3, strmsg("not vec3 type"));
    *pp_res = (vec3_t*)obj;
    (*pp_res)->ref.addref(&(*pp_res)->ref);    
}

//wirte [x, y, z] to buf
static int tostr(char *buf, /*in*/ vec3_t *self) {
    int i = 0;
    i += sprintf(buf + i, "[ ");
    i += self->x->tostr(buf + i, self->x);  i += sprintf(buf + i, ", ");
    i += self->y->tostr(buf + i, self->y);  i += sprintf(buf + i, ", ");
    i += self->z->tostr(buf + i, self->z);  i += sprintf(buf + i, " ]");
    return i;
}

//TODO: implement vec3_release
static void vec3_release(refobj_t *self) {
    is_vec3(self);
    vec3_t *v = (vec3_t*)self;


}

//TODO: implement vec3_add
//e.g. add([1, 2, 3], [4, 5, 6]) = [1+4, 2+5, 3+6]
static void vec3_add(/*in*/ vec3_t *a, /*in*/ vec3_t *b, /*out*/ vec3_t **pp_res) {
    is_vec3(a);
    is_vec3(b);

    complex_t *x, *y, *z;


}

//TODO: implement vec3_sub
//e.g. sub([1, 2, 3], [4, 5, 6]) = [1-4, 2-5, 3-6]
static void vec3_sub(/*in*/ vec3_t *a, /*in*/ vec3_t *b, /*out*/ vec3_t **pp_res) {
    is_vec3(a);
    is_vec3(b);

    complex_t *x, *y, *z;


}

//TODO: implement vec3_smul
//scalar multiplication, e.g. smul(2, [1, 2, 3]) = [2, 4, 6]
static void vec3_smul(/*in*/ complex_t *s, /*in*/ vec3_t *a, /*out*/ vec3_t **pp_res) {
    is_vec3(a);

    complex_t *x, *y, *z;


}

//TODO: implement vec3_prod
//inner product, e.g. prod([1, 2, 3], [4, 5, 6]) = 1*4 + 2*5 + 3*6 = 32
static void vec3_prod(/*in*/ vec3_t *a, /*in*/ vec3_t *b, /*out*/ complex_t **pp_res) {
    is_vec3(a);
    is_vec3(b);

    complex_t *x, *y, *z, *t;


}

//TODO: implement vec3_make
void vec3_make(/*in*/ complex_t *x, /*in*/ complex_t *y, /*in*/ complex_t *z, /*out*/ vec3_t **pp_res) {
    vec3_t *v = refobj_alloc(OBJ_VEC3, sizeof(vec3_t));
    v->ref.release = vec3_release;


}
