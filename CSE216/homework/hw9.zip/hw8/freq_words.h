#ifndef __FREQ_WORDS__
#define __FREQ_WORDS__

typedef struct word_freq {
    char *word;
    int  freq;
} word_freq_t;

//TODO: add function declarations

#endif
