#use "parser.ml"

(*print expr*)
let print expr =
    (*TODO: implement to_str in CPS*)
    let rec to_str e k =

   
    to_str expr (Printf.printf "%s\n")
 

(*evaluate expr in env*)
(*TODO: implement eval in CPS*)
let rec eval expr env k =
    let dropNUM  = function NUM  n -> n | e -> print e; assert false in
    let dropBOOL = function BOOL b -> b | e -> print e; assert false in
    let dropCLO  = function CLO (v, e, ev) -> (v, e, ev) | e -> print e; assert false in

    (*look up the value of a variable from an environment*)
    let rec lookup name env =
        match env with
        | [] -> print (VAR name); assert false
        | (n, e)::rest -> if name = n
                        then e
                        else lookup name rest in


