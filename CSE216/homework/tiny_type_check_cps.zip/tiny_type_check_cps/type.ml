#use "parser.ml"

(*print kind*)
let print_kind knd =
    (*TODO: implement to_str in CPS*)
    let rec to_str knd k =


    to_str knd (Printf.printf "%s\n")

(*kind of expr in env*)
(*TODO: implement kind in CPS*)
let rec kind expr env k =
    (*look up the kind of a variable from an environment*)
    let rec lookup name env =
        match env with
        | [] -> Error
        | (n, knd)::rest -> if name = n
                        then knd
                        else lookup name rest in

